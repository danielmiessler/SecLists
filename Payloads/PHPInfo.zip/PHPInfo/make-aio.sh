#!/bin/sh
zip phpinfo-aio.zip phpinfo*.{p*,txt,jp*g,gif}

tar -cvf phpinfo-aio.tar phpinfo*.{p*,txt,jp*g,gif}

