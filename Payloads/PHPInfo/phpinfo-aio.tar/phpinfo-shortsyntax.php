//tested on 7.2
// even with short_open_tag=0
<?=phpinfo()?>
